<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <link rel="stylesheet" href="<?php echo base_url('asset/css/style.css'); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap" rel="stylesheet">
</head>
<body>


		<header>
			<div class="head">
				<a href=""> <img src="" alt="">Web Application</a>
			</div>

		</header>

			<div class="sec">

			</div>


			<table border="1" width="100%">
				<tr>
					<th colspan="7">Data</th>
				</tr>
				<tr>
					<th>ID</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Email</th>
					<th>Account Created</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
				<tr align="center">
					<?php
					if ($tbl_data) {
						foreach ($tbl_data as $key) {
							?>
							<tr align="center">
								<td><?php echo $key->id; ?></td>
								<td><?php echo $key->fname; ?></td>
								<td><?php echo $key->lname; ?></td>
								<td><?php echo $key->email; ?></td>
								<td><?php echo $key->account_created; ?></td>
								<td><button id="edit">Edit</button></td>
								<td><button id="delete">Delete</button></td>
							</tr>

							<?php
						}
					}

					?>
				<!--	<td>1</td>
					<td>Dela pena</td>
					<td>Jemwel</td>
					<td>Jemweldelapena@gmail.com</td>
					<td>April 13 2000</td>
					<td><button id="edit">Edit</button></td>
					<td><button id="delete">Delete</button></td>  -->
				<tr>
			</Table>




</body>
</html>