<?php 




	class Db_data extends CI_Model
	{
		public function getdata()
		{
			$table = $this->db->table_exists('delapena');
			if($table) {
				$query = $this->db->get('delapena');
				if($query->num_rows() > 0 ){
					return $query->result();
				}
				else{
					return false;
				}
			}
		}


	}




?>