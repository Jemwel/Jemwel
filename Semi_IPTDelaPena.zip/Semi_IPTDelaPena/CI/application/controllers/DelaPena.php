<?php 

defined('BASEPATH') OR exit('No direct script access allowed');





class DelaPena extends CI_Controller
{

	function __construct(){
		parent:: __construct();
		// data is a variable 
		$this->load->model('Db_data','d');

	}


	function index()
	{

		$data['tbl_data'] = $this->d->getdata();

		//echo 'Hello jem';

		// $this->load->view('header/head');
		$this->load->view('sample/index', $data);
		// $this->load->view('footer/foot');
	}

}



?>

